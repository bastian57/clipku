package com.daftech.clipku.youtube

import com.daftech.clipku.model.CaptionTrack
import com.daftech.clipku.model.HeatPoint
import com.daftech.clipku.model.Sentence
import com.daftech.clipku.model.VideoInfo
import com.daftech.clipku.model.VideoStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Klien Innertube YouTube (player API) via OkHttp.
 *
 * Jalur UTAMA v1: WEB. Jalur fallback v1.0.1: timedtext direct, lalu
 * klien ANDROID — keduanya hanya jalan kalau jalur sebelumnya kosong.
 *
 * Kunci "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8" adalah kunci WEB PUBLIK
 * YouTube yang dipakai klien web resmi, BUKAN kredensial pribadi Putra dan
 * BUKAN Groq key. Tidak ada secret Putra di file ini.
 *
 * Keterbatasan jujur: YouTube tidak mendokumentasikan endpoint ini dan bisa
 * mengubah responsnya sewaktu-waktu. Kalau respons berubah, analisa gagal
 * dengan pesan jelas (bukan hasil ngarang) sampai parser diperbarui.
 * signatureCipher TIDAK di-decipher di fix ini (butuh decipher JS player,
 * di luar scope v1.0.1) — lihat FIX-NOTES-v1.0.1.md untuk fallback
 * masa depan (NewPipeExtractor / yt-dlp) kalau ANDROID juga cipher-only.
 */

/** Hasil transkrip beserta label sumbernya, untuk diagnostik UI. */
data class TranscriptResult(
    val sentences: List<Sentence>,
    val source: String
)

class InnertubeClient(
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
) {
    companion object {
        // Kunci web publik YouTube (lihat komentar kelas). Bukan secret.
        private const val WEB_API_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        private const val PLAYER_URL =
            "https://www.youtube.com/youtubei/v1/player?key=$WEB_API_KEY"
        private const val BROWSER_UA =
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Safari/537.36"
        // Klien ANDROID 19.x — lini klien Android yang dipakai luas
        // sepanjang 2025. Kalau YouTube menolak versi ini, fallback ini
        // mengembalikan kosong (tidak crash) dan sumber sebelumnya tetap
        // dipakai; versi ini bukan jaminan, melainkan best-effort.
        private const val ANDROID_CLIENT_VERSION = "19.47.53"
        // v1.3.0 (#3): batch paralel transkrip — maks 4 track
        // sekaligus (rate limit IP), maks 12 track total per sumber.
        private const val MAX_PARALLEL_TRACKS = 4
        private const val MAX_TRACKS_TO_TRY = 12
    }

    /** Cache respons ANDROID dari merge stream, dipakai ulang oleh fallback transkrip. */
    private var cachedAndroidInfo: VideoInfo? = null

    /** v1.0.3: jumlah track caption yang dicoba pada fetchTranscriptWithFallback terakhir. */
    var lastTracksTried: Int = 0
        private set

    /**
     * Sumber stream Innertube terakhir yang berhasil dipakai fetchVideoInfo:
     * "WEB", "WEB+ANDROID" (ANDROID mengisi yang kosong dari WEB), atau
     * "NONE". Dibaca ViewModel untuk diagnostik. NewPipe TIDAK mengubah
     * nilai ini — sumber NEWPIPE dicatat terpisah di ViewModel, karena
     * NewPipe di-merge SETELAH fetchVideoInfo selesai.
     */
    var lastStreamSource: String = "NONE"
        private set

    suspend fun fetchVideoInfo(videoId: String): VideoInfo = withContext(Dispatchers.IO) {
        val webRoot = fetchPlayer(videoId, "WEB", "2.20240111.09.00")
        var info = parseVideoInfo(videoId, webRoot)
        val webAudio = info.stream.audioUrl
        val webProgressive = info.stream.progressiveUrl
        lastStreamSource = if (webAudio != null || webProgressive != null) "WEB" else "NONE"
        // v1.0.1: fallback stream ANDROID, hanya kalau WEB kekurangan stream.
        // Format ANDROID sering berupa URL langsung, sedangkan format WEB
        // sering hanya signatureCipher (yang tidak dibaca / tidak di-decipher
        // di fix ini), sehingga audioUrl / progressiveUrl WEB bisa null.
        if (info.stream.audioUrl == null || info.stream.progressiveUrl == null) {
            try {
                val androidInfo = fetchAndroidVideoInfo(videoId)
                if (androidInfo != null) {
                    cachedAndroidInfo = androidInfo
                    if ((webAudio == null && androidInfo.stream.audioUrl != null) ||
                        (webProgressive == null && androidInfo.stream.progressiveUrl != null)
                    ) {
                        lastStreamSource = "WEB+ANDROID"
                    }
                    val mergedStream = VideoStream(
                        progressiveUrl = info.stream.progressiveUrl
                            ?: androidInfo.stream.progressiveUrl,
                        videoOnlyUrl = info.stream.videoOnlyUrl
                            ?: androidInfo.stream.videoOnlyUrl,
                        audioUrl = info.stream.audioUrl
                            ?: androidInfo.stream.audioUrl,
                        mimeProgressive = info.stream.mimeProgressive,
                        // v1.0.5: deskripsi track mengikuti SUMBER audioUrl
                        // yang menang (WEB kalau WEB punya audio, kalau
                        // tidak ANDROID) — jangan sampai deskripsi
                        // ANDROID menempel di URL WEB atau sebaliknya.
                        audioTrackDescription = if (info.stream.audioUrl != null) {
                            info.stream.audioTrackDescription
                        } else {
                            androidInfo.stream.audioTrackDescription
                        }
                    )
                    info = info.copy(
                        stream = mergedStream,
                        captionTracks = if (info.captionTracks.isNotEmpty()) {
                            info.captionTracks
                        } else {
                            androidInfo.captionTracks
                        },
                        heatPoints = if (info.heatPoints.isNotEmpty()) {
                            info.heatPoints
                        } else {
                            androidInfo.heatPoints
                        }
                    )
                }
            } catch (e: Exception) {
                // Fallback gagal = pakai hasil WEB apa adanya, bukan crash.
            }
        }
        info
    }

    /** Satu POST player, dengan clientName / clientVersion yang diminta. */
    private suspend fun fetchPlayer(
        videoId: String,
        clientName: String,
        clientVersion: String
    ): JSONObject = withContext(Dispatchers.IO) {
        val bodyJson = JSONObject().apply {
            put("videoId", videoId)
            put("context", JSONObject().apply {
                put("client", JSONObject().apply {
                    put("clientName", clientName)
                    put("clientVersion", clientVersion)
                    put("hl", "id")
                    put("gl", "ID")
                })
            })
        }
        val request = Request.Builder()
            .url(PLAYER_URL)
            .header("Content-Type", "application/json")
            .header("User-Agent", BROWSER_UA)
            .post(bodyJson.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val response = http.newCall(request).execute()
        val text = response.body?.string() ?: ""
        response.close()
        if (!response.isSuccessful) {
            throw IllegalStateException(
                "Innertube gagal (HTTP ${response.code}). " +
                    "YouTube mungkin mengubah player-nya atau memblokir permintaan ini."
            )
        }
        JSONObject(text)
    }

    /** Player ANDROID, best-effort: null kalau gagal, tidak pernah melempar. */
    private suspend fun fetchAndroidVideoInfo(videoId: String): VideoInfo? {
        return try {
            val root = fetchPlayer(videoId, "ANDROID", ANDROID_CLIENT_VERSION)
            parseVideoInfo(videoId, root)
        } catch (e: Exception) {
            null
        }
    }

    private fun parseVideoInfo(videoId: String, root: JSONObject): VideoInfo {
        val details = root.optJSONObject("videoDetails") ?: JSONObject()
        val title = details.optString("title", "Video tanpa judul")
        val author = details.optString("author", "")
        val durationMs = (details.optString("lengthSeconds", "0").toLongOrNull() ?: 0L) * 1000L
        if (durationMs <= 0L) {
            // playabilityStatus bisa menjelaskan: private / age-gated / tidak ada.
            val status = root.optJSONObject("playabilityStatus")?.optString("status", "")
            val reason = root.optJSONObject("playabilityStatus")?.optString("reason", "")
            throw IllegalStateException(
                "Video tidak bisa dianalisa (status: $status $reason). " +
                    "Video privat, dibatasi usia, atau tidak ditemukan tidak didukung v1."
            )
        }

        val captions = parseCaptions(root)
        // v1.0.8 P0-3: heatmap butuh durasi untuk fraksi marker.
        val heat = HeatmapParser.parse(root, durationMs)
        val streaming = root.optJSONObject("streamingData") ?: JSONObject()
        val progressive = pickProgressive(streaming.optJSONArray("formats"))
        val adaptiveVideo = pickAdaptiveVideo(streaming.optJSONArray("adaptiveFormats"))
        // v1.0.5: caption dibaca DULU supaya bahasa video diketahui
        // sebelum audio dipilih (ranking butuh bahasa preferensi).
        val adaptiveAudio = pickAdaptiveAudio(
            streaming.optJSONArray("adaptiveFormats"),
            preferredLanguageFromCaptions(captions)
        )
        val stream = VideoStream(
            progressiveUrl = progressive,
            videoOnlyUrl = adaptiveVideo,
            audioUrl = adaptiveAudio?.url,
            mimeProgressive = null,
            audioTrackDescription = adaptiveAudio?.description ?: ""
        )

        return VideoInfo(
            videoId = videoId,
            title = title,
            author = author,
            durationMs = durationMs,
            stream = stream,
            captionTracks = captions,
            heatPoints = heat,
            chapters = emptyList()
        )
    }

    /** Format gabungan mp4 <=720p, diutamakan yang tertinggi di bawah 720p. */
    private fun pickProgressive(formats: JSONArray?): String? {
        if (formats == null) return null
        var best: String? = null
        var bestHeight = -1
        for (i in 0 until formats.length()) {
            val item = formats.optJSONObject(i) ?: continue
            val mime = item.optString("mimeType", "")
            if (!mime.contains("video/mp4")) continue
            val height = item.optInt("height", 0)
            if (height <= 0 || height > 720) continue
            val url = item.optString("url", "").ifEmpty { null } ?: continue
            if (height > bestHeight) {
                bestHeight = height
                best = url
            }
        }
        // Fallback: format gabungan apa pun (mis. 360p webm) kalau mp4 tidak ada.
        if (best == null) {
            for (i in 0 until formats.length()) {
                val item = formats.optJSONObject(i) ?: continue
                val url = item.optString("url", "").ifEmpty { null } ?: continue
                return url
            }
        }
        return best
    }

    private fun pickAdaptiveVideo(formats: JSONArray?): String? {
        if (formats == null) return null
        var best: String? = null
        var bestHeight = -1
        for (i in 0 until formats.length()) {
            val item = formats.optJSONObject(i) ?: continue
            val mime = item.optString("mimeType", "")
            if (!mime.startsWith("video/mp4")) continue
            val height = item.optInt("height", 0)
            if (height <= 0 || height > 720) continue
            val url = item.optString("url", "").ifEmpty { null } ?: continue
            if (height > bestHeight) {
                bestHeight = height
                best = url
            }
        }
        return best
    }

    /**
     * v1.0.5: pilih audio ADAPTIVE sadar-bahasa, bukan bitrate tertinggi
     * buta. Tiap format adaptive membawa `audioTrack`:
     * `{ "displayName": "Bahasa Indonesia", "id": "...",
     * "audioIsDefault": true }` — Innertube TIDAK memberi flag
     * ORIGINAL/DUBBED eksplisit seperti NewPipe, jadi tipenya
     * dilaporkan jujur sebagai "default"/"non-default" (lihat
     * describeInnertubeAudio), bukan diklaim "original".
     * Ranking (angka kecil menang):
     *  0 = default + bahasa cocok dengan bahasa video
     *  1 = bahasa cocok (bukan default)
     *  2 = default (bahasa lain / bahasa tidak diketahui)
     *  3 = displayName mengandung "original"
     *  4 = sisanya
     * Di dalam satu tingkat: bitrate tertinggi (fallback lama).
     * Track dub TIDAK PERNAH menang hanya karena bitrate-nya lebih
     * besar — itu bug v1.0.4 (clip Rocky Gerung jadi berbahasa Inggris).
     */
    private data class AdaptiveAudioPick(val url: String, val description: String)

    private fun pickAdaptiveAudio(
        formats: JSONArray?,
        preferred: String
    ): AdaptiveAudioPick? {
        if (formats == null) return null
        var best: AdaptiveAudioPick? = null
        var bestRank = Int.MAX_VALUE
        var bestBitrate = -1
        for (i in 0 until formats.length()) {
            val item = formats.optJSONObject(i) ?: continue
            val mime = item.optString("mimeType", "")
            if (!mime.startsWith("audio/")) continue
            val bitrate = item.optInt("bitrate", 0)
            val url = item.optString("url", "").ifEmpty { null } ?: continue
            val track = item.optJSONObject("audioTrack")
            val isDefault = track?.optBoolean("audioIsDefault", false) == true
            val displayName = track?.optString("displayName", "")?.trim() ?: ""
            val lang = languageFromDisplayName(displayName)
            val rank = when {
                isDefault && lang == preferred -> 0
                lang == preferred -> 1
                isDefault -> 2
                "original" in displayName.lowercase() -> 3
                else -> 4
            }
            if (rank < bestRank || (rank == bestRank && bitrate > bestBitrate)) {
                bestRank = rank
                bestBitrate = bitrate
                best = AdaptiveAudioPick(
                    url,
                    describeInnertubeAudio(lang, isDefault, displayName)
                )
            }
        }
        return best
    }

    /**
     * Bahasa video dari caption: "id" kalau ada track caption id,
     * kalau tidak bahasa caption pertama, kalau tidak ada caption
     * sama sekali default "id" (pengguna utama berbahasa Indonesia;
     * ranking tetap jatuh ke default/bitrate kalau video ternyata
     * bukan Indonesia dan tidak ada info bahasa).
     */
    private fun preferredLanguageFromCaptions(tracks: List<CaptionTrack>): String {
        if (tracks.any { it.languageCode.startsWith("id") }) return "id"
        val first = tracks.firstOrNull()?.languageCode
            ?.take(2)?.lowercase()?.takeIf { it.isNotBlank() }
        return first ?: "id"
    }

    /** displayName ("Bahasa Indonesia" / "English") -> kode 2 huruf, null kalau tidak dikenal. */
    private fun languageFromDisplayName(displayName: String): String? {
        val lower = displayName.lowercase()
        return when {
            "indonesia" in lower -> "id"
            "english" in lower || "inggris" in lower -> "en"
            "javanese" in lower || lower.contains("jawa") -> "jv"
            "sundanese" in lower || lower.contains("sunda") -> "su"
            "malay" in lower || "melayu" in lower -> "ms"
            else -> null
        }
    }

    /** "id, default (Bahasa Indonesia)" / "en, non-default (English)" / "?, non-default". */
    private fun describeInnertubeAudio(
        lang: String?,
        isDefault: Boolean,
        displayName: String
    ): String {
        val langText = lang ?: "?"
        val typeText = if (isDefault) "default" else "non-default"
        return if (displayName.isNotBlank() && displayName.lowercase() != langText) {
            "$langText, $typeText ($displayName)"
        } else {
            "$langText, $typeText"
        }
    }

    private fun parseCaptions(root: JSONObject): List<CaptionTrack> {
        val out = mutableListOf<CaptionTrack>()
        val tracks = root.optJSONObject("captions")
            ?.optJSONObject("playerCaptionsTracklist")
            ?.optJSONArray("captionTracks") ?: return out
        for (i in 0 until tracks.length()) {
            val item = tracks.optJSONObject(i) ?: continue
            val baseUrl = item.optString("baseUrl", "").ifEmpty { null } ?: continue
            out.add(
                CaptionTrack(
                    baseUrl = baseUrl,
                    languageCode = item.optString("languageCode", ""),
                    name = item.optJSONObject("name")?.optString("simpleText", "")
                        ?: item.optString("languageCode", ""),
                    isAutoGenerated = item.optString("kind", "") == "asr"
                )
            )
        }
        return out
    }

    /** Kompatibilitas v1.0.0: hanya kalimatnya, tanpa label sumber. */
    suspend fun fetchTranscript(info: VideoInfo): List<Sentence> =
        fetchTranscriptWithFallback(info).sentences

    /**
     * Rantai fallback transkrip v1.0.1, berurutan, pertama yang berhasil menang:
     * 1. WEB — captionTracks dari fetchVideoInfo, format VTT.
     * 2. TIMEDTEXT — endpoint timedtext langsung (id, lalu en), format json3.
     * 3. ANDROID — captionTracks dari player ANDROID, format VTT.
     * Tiap langkah yang gagal / kosong tidak melempar; hasil kosong
     * mengembalikan sumber "NONE" supaya diagnostik bisa menyebutnya.
     */
    suspend fun fetchTranscriptWithFallback(info: VideoInfo): TranscriptResult =
        withContext(Dispatchers.IO) {
            lastTracksTried = 0
            val web = fetchTranscriptFromTracks(info.captionTracks)
            if (web.isNotEmpty()) {
                return@withContext TranscriptResult(web, "WEB")
            }
            val timedtextId = fetchTimedtext(info.videoId, "id")
            if (timedtextId.isNotEmpty()) {
                return@withContext TranscriptResult(timedtextId, "TIMEDTEXT")
            }
            val timedtextEn = fetchTimedtext(info.videoId, "en")
            if (timedtextEn.isNotEmpty()) {
                return@withContext TranscriptResult(timedtextEn, "TIMEDTEXT")
            }
            val androidInfo = cachedAndroidInfo ?: fetchAndroidVideoInfo(info.videoId)
            if (androidInfo != null) {
                cachedAndroidInfo = androidInfo
                val android = fetchTranscriptFromTracks(androidInfo.captionTracks)
                if (android.isNotEmpty()) {
                    return@withContext TranscriptResult(android, "ANDROID")
                }
            }
            TranscriptResult(emptyList(), "NONE")
        }

    /**
     * v1.3.0 (#3): coba track PARALEL, bukan berurutan (P1-8: dulu
     * ~50 track x (VTT+json3) berurutan, timeout 30 detik tiap
     * request — tahap transkrip bisa menggantung lama). Batch maks
     * 4 track sekaligus (lebih dari itu mengundang rate limit IP,
     * riset §1.1: IP kena block setelah ~30 fetch), maks 3 batch
     * (12 track — id/en manual+auto sudah tercakup di batch awal).
     * Per track dicoba json3 DULU (lebih kecil + timing langsung),
     * VTT sebagai fallback. Track pertama yang menghasilkan kalimat
     * tidak kosong menang; sisanya di-cancel. Gagal semua di batch
     * ini = lanjut ke batch berikut, lalu ke rantai TIMEDTEXT/
     * ANDROID di fetchTranscriptWithFallback seperti dulu.
     * lastTracksTried = jumlah track yang benar-benar dimulai.
     */
    private suspend fun fetchTranscriptFromTracks(
        tracks: List<CaptionTrack>
    ): List<Sentence> = withContext(Dispatchers.IO) {
        val ordered = mutableListOf<CaptionTrack>()
        fun addAll(predicate: (CaptionTrack) -> Boolean) {
            for (track in tracks) {
                if (predicate(track) && ordered.none { it.baseUrl == track.baseUrl }) {
                    ordered.add(track)
                }
            }
        }
        addAll { it.languageCode.startsWith("id") && !it.isAutoGenerated }
        addAll { it.languageCode.startsWith("id") }
        addAll { it.languageCode.startsWith("en") && !it.isAutoGenerated }
        addAll { it.languageCode.startsWith("en") }
        addAll { true }
        for (batch in ordered.take(MAX_TRACKS_TO_TRY).chunked(MAX_PARALLEL_TRACKS)) {
            val result = fetchTrackBatch(batch)
            if (result.isNotEmpty()) return@withContext result
        }
        emptyList()
    }

    /**
     * v1.3.0 (#3): satu batch track paralel — yang pertama selesai
     * dengan kalimat tidak kosong menang; hasil kosong yang selesai
     * bersamaan ikut diperiksa supaya tidak terbuang.
     */
    private suspend fun fetchTrackBatch(
        batch: List<CaptionTrack>
    ): List<Sentence> = coroutineScope {
        lastTracksTried += batch.size
        val pending = batch.mapIndexed { index, track ->
            async(Dispatchers.IO) { index to fetchSingleTrack(track) }
        }.toMutableList()
        while (pending.isNotEmpty()) {
            val (_, firstSentences) = select<Pair<Int, List<Sentence>>> {
                pending.forEach { deferred -> deferred.onAwait { it } }
            }
            // Semua yang selesai di ronde ini (bisa lebih dari satu).
            val done = pending.filter { it.isCompleted }
            pending.removeAll(done)
            if (firstSentences.isNotEmpty()) {
                pending.forEach { it.cancel() }
                return@coroutineScope firstSentences
            }
            for (deferred in done) {
                val sentences = runCatching { deferred.getCompleted() }
                    .getOrNull()?.second ?: continue
                if (sentences.isNotEmpty()) {
                    pending.forEach { it.cancel() }
                    return@coroutineScope sentences
                }
            }
        }
        emptyList()
    }

    /** v1.3.0 (#3): satu track — json3 dulu, VTT fallback. */
    private suspend fun fetchSingleTrack(track: CaptionTrack): List<Sentence> {
        val json = fetchText(withFmt(track.baseUrl, "json3"))
        if (json != null) {
            val sentences = parseJson3Text(json)
            if (sentences.isNotEmpty()) return sentences
        }
        val vtt = fetchText(withFmt(track.baseUrl, "vtt"))
        if (vtt != null) {
            val sentences = VttParser.parse(vtt)
            if (sentences.isNotEmpty()) return sentences
        }
        return emptyList()
    }

    /** Ganti/tambah parameter fmt pada URL subtitle, tanpa menumpuk fmt. */
    private fun withFmt(baseUrl: String, fmt: String): String {
        return if (baseUrl.contains("fmt=")) {
            baseUrl.replace(Regex("fmt=[^&]*"), "fmt=$fmt")
        } else if (baseUrl.contains("?")) {
            "$baseUrl&fmt=$fmt"
        } else {
            "$baseUrl?fmt=$fmt"
        }
    }

    /** GET teks dari URL, null kalau HTTP gagal / kosong / exception. */
    private suspend fun fetchText(url: String): String? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", BROWSER_UA)
                .build()
            val response = http.newCall(request).execute()
            val text = response.body?.string() ?: ""
            response.close()
            if (!response.isSuccessful || text.isBlank()) null else text
        } catch (e: Exception) {
            null
        }
    }

    /** Parser json3 dipakai ulang oleh fetchTimedtext dan fallback per track. */
    private fun parseJson3Text(text: String): List<Sentence> {
        try {
            val root = JSONObject(text)
            val events = root.optJSONArray("events") ?: return emptyList()
            val out = mutableListOf<Sentence>()
            for (i in 0 until events.length()) {
                val event = events.optJSONObject(i) ?: continue
                val start = event.optLong("tStartMs", -1L)
                if (start < 0) continue
                val duration = event.optLong("dDurationMs", 0L)
                val segs = event.optJSONArray("segs") ?: continue
                val builder = StringBuilder()
                for (j in 0 until segs.length()) {
                    val seg = segs.optJSONObject(j) ?: continue
                    builder.append(seg.optString("utf8", ""))
                }
                val clean = builder.toString()
                    .replace(Regex("<[^>]+>"), " ")
                    .replace(Regex("\\s+"), " ")
                    .trim()
                if (clean.isNotEmpty()) {
                    out.add(Sentence(start, start + duration, clean))
                }
            }
            return out
        } catch (e: Exception) {
            return emptyList()
        }
    }

    /**
     * Timedtext langsung: GET /api/timedtext?v={id}&lang={lang}&fmt=json3.
     * Format json3: { "events": [ { "tStartMs": N, "dDurationMs": N,
     * "segs": [ { "utf8": "..." } ] } ] }. Tag HTML dibuang.
     * HTTP non-200 (termasuk 403 untuk caption auto di beberapa video)
     * diperlakukan sebagai kosong, bukan error.
     */
    private suspend fun fetchTimedtext(videoId: String, lang: String): List<Sentence> =
        withContext(Dispatchers.IO) {
            val text = fetchText(
                "https://www.youtube.com/api/timedtext?v=$videoId&lang=$lang&fmt=json3"
            ) ?: return@withContext emptyList()
            parseJson3Text(text)
        }
}
